export interface NgxFileUploadValidationErrors {
    [key: string]: any;
}
export declare type NgxFileUploadValidationFn = (file: File) => NgxFileUploadValidationErrors | null;
export interface NgxFileUploadValidator {
    validate(file: File): NgxFileUploadValidationErrors | null;
}
