import * as i0 from "@angular/core";
import * as i1 from "@angular/common/http";
export declare class NgxFileUploadCoreModule {
    static ɵfac: i0.ɵɵFactoryDeclaration<NgxFileUploadCoreModule, never>;
    static ɵmod: i0.ɵɵNgModuleDeclaration<NgxFileUploadCoreModule, never, [typeof i1.HttpClientModule], never>;
    static ɵinj: i0.ɵɵInjectorDeclaration<NgxFileUploadCoreModule>;
}
