import { InjectionToken } from "@angular/core";
import { INgxFileUploadRequest, NgxFileUploadOptions, NgxFileUploadValidation } from "../../api";
export interface NgxFileUploadFactory {
    createUploadRequest(file: File | File[], options: NgxFileUploadOptions, validator?: NgxFileUploadValidation | null): INgxFileUploadRequest | null;
}
/**
 * InjectionToken for NgxFileuploadFactory
 */
export declare const NgxFileUploadFactory: InjectionToken<NgxFileUploadFactory>;
