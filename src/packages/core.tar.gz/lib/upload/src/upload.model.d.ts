import { NgxFileUploadValidationErrors, INgxFileUploadFile } from "../../api";
export declare class NgxFileUploadFile implements INgxFileUploadFile {
    readonly raw: File;
    readonly size: number;
    readonly name: string;
    readonly type: string;
    validationErrors: NgxFileUploadValidationErrors | null;
    constructor(file: File);
}
