import { INgxFileUploadRequest } from "../../api";
export declare class NgxFileUploadQueue {
    private active;
    private queuedUploads;
    private concurrentCount;
    private observedUploads;
    set concurrent(count: number);
    register(upload: INgxFileUploadRequest): void;
    /**
     * create before start hook, if any upload wants to start we have to check
     */
    private createBeforeStartHook;
    /**
     * register to upload change
     */
    private registerUploadChange;
    private writeToQueue;
    /**
     * requests gets completed, this means request is pending or was progressing and the user
     * cancel request, remove it or even destroys them
     */
    private requestCompleted;
    /**
     * checks upload is in queue
     */
    private isInUploadQueue;
    /**
     * remove upload request from queued uploads
     */
    private removeFromQueue;
    /**
     * try to start next upload in queue, returns false if no further uploads
     * exists
     */
    private startNextInQueue;
}
