import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";
import { NgxFileUploadState, INgxFileUploadRequest, NgxFileUploadOptions, INgxFileUploadRequestData } from "../../api";
import { NgxFileUploadFile } from "./upload.model";
export declare class NgxFileUploadRequest implements INgxFileUploadRequest {
    private http;
    private cancel$;
    private change$;
    private destroyed$;
    private totalSize;
    private options;
    private model;
    private hooks;
    get change(): Observable<INgxFileUploadRequestData>;
    get destroyed(): Observable<boolean>;
    get data(): INgxFileUploadRequestData;
    set state(state: NgxFileUploadState);
    get state(): NgxFileUploadState;
    requestId: string;
    constructor(http: HttpClient, files: NgxFileUploadFile | NgxFileUploadFile[], options: NgxFileUploadOptions);
    beforeStart(hook: Observable<boolean>): void;
    /**
     * cancel current file upload, this will complete change subject
     */
    cancel(): void;
    destroy(): void;
    /**
     * return true if upload was not completed since the server
     * sends back an error response
     */
    hasError(): boolean;
    isCompleted(ignoreError?: boolean): boolean;
    isCanceled(): boolean;
    isInvalid(): boolean;
    isProgress(): boolean;
    isPending(): boolean;
    isIdle(): boolean;
    isRequestCompleted(): boolean;
    /**
     * restart download again
     * reset state, and reset errors
     */
    retry(): void;
    /**
     * start file upload
     */
    start(): void;
    removeInvalidFiles(): void;
    /**
     * call hooks in order, see playground
     * @see https://rxviz.com/v/58GkkYv8
     */
    private get beforeStartHook$();
    /**
     * build form data and send request to server
     */
    private startUploadRequest;
    /**
     * create upload body which will should be send
     */
    private createUploadBody;
    /**
     * create upload request headers
     */
    private createUploadHeaders;
    /**
     * create authorization header which will send
     */
    private createAuthroizationHeader;
    /**
     * request responds with an error
     */
    private handleError;
    /**
     * handle all http events
     */
    private handleHttpEvent;
    /**
     * handle http progress event
     */
    private handleProgress;
    /**
     * upload completed with an success
     */
    private handleResponse;
    /**
     * send notification to observers
     */
    private notifyObservers;
    /**
     * upload has been completed, canceled or destroyed
     */
    private finalizeUpload;
}
