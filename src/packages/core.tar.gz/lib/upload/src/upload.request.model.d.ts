import { INgxFileUploadFile, INgxFileUploadRequestData, INgxFileUploadRequestModel, NgxFileUploadResponse, NgxFileUploadState, NgxFileUploadValidationErrors } from "../../api";
import { NgxFileUploadFile } from "./upload.model";
/**
 * Represents an upload request, and store the data inside
 */
export declare class NgxFileUploadRequestModel implements INgxFileUploadRequestModel {
    private filesToUpload;
    constructor(file: INgxFileUploadFile | INgxFileUploadFile[]);
    get files(): NgxFileUploadFile[];
    get name(): string[];
    get size(): number;
    get validationErrors(): NgxFileUploadValidationErrors | null;
    response: NgxFileUploadResponse;
    state: NgxFileUploadState;
    uploaded: number;
    progress: number;
    hasError: boolean;
    toJson(): INgxFileUploadRequestData;
}
