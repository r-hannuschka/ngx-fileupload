import { Observable } from "rxjs";
import { INgxFileUploadRequest, NgxFileUploadStorageConfig } from "../../api";
export declare class NgxFileUploadStorage {
    private change$;
    private uploads;
    private uploadQueue;
    private storeConfig;
    private destroyed$;
    private bulkProcess;
    constructor(config?: NgxFileUploadStorageConfig);
    /**
     * submits if any upload changes his state, uploads
     * gets removed or added
     */
    change(): Observable<INgxFileUploadRequest[]>;
    /**
     * add new upload to store
     */
    add(upload: INgxFileUploadRequest | INgxFileUploadRequest[]): void;
    destroy(): void;
    remove(upload: INgxFileUploadRequest | string): void;
    purge(): void;
    startAll(): void;
    stopAll(): void;
    removeInvalid(): void;
    private registerUploadEvents;
    private queueRequest;
    /**
     * @description register to request change events, this will notify all observers
     * if state from upload state has been changed, this will not notify
     * if amount of uploaded size has been changed
     */
    private handleRequestChange;
    private afterUploadsAdd;
    private generateUniqeRequestId;
    private notifyObserver;
    private removeBulkProcess;
    private isBulkProcess;
}
