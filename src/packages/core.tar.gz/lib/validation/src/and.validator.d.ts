import { NgxFileUploadGroupedvalidator } from "./grouped.validator";
import { NgxFileUploadValidationErrors } from "../../api";
export declare class NgxFileUploadAndValidator extends NgxFileUploadGroupedvalidator {
    validate(file: File): NgxFileUploadValidationErrors | null;
}
