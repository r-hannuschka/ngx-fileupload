import { NgxFileUploadValidationErrors, NgxFileUploadValidation, NgxFileUploadValidator } from "../../api";
export declare abstract class NgxFileUploadGroupedvalidator implements NgxFileUploadValidator {
    protected validators: Array<NgxFileUploadValidation>;
    constructor(validators?: Array<NgxFileUploadValidation>);
    abstract validate(file: File): NgxFileUploadValidationErrors | null;
    /**
     * add validators
     */
    add(...validators: Array<NgxFileUploadValidation>): void;
    /**
     * clean up all validators
     */
    clean(): void;
    /**
     * executes validator and returns validation result
     */
    protected execValidator(validator: NgxFileUploadValidation, file: File): NgxFileUploadValidationErrors | null;
}
