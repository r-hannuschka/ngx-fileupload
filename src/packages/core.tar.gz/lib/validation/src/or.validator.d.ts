import { NgxFileUploadValidationErrors } from "../../api";
import { NgxFileUploadGroupedvalidator } from "./grouped.validator";
export declare class NgxFileUploadOrValidator extends NgxFileUploadGroupedvalidator {
    validate(file: File): NgxFileUploadValidationErrors | null;
}
