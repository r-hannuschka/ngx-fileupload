import { NgxFileUploadGroupedvalidator } from "./grouped.validator";
import { NgxFileUploadValidation } from "../../api";
export declare class NgxFileUploadValidationBuilder {
    static and(...validators: Array<NgxFileUploadValidation>): NgxFileUploadGroupedvalidator;
    static or(...validators: Array<NgxFileUploadValidation>): NgxFileUploadGroupedvalidator;
}
