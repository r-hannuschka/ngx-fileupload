"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const architect_1 = require("@angular-devkit/architect");
const progress_schema_1 = require("@angular-devkit/architect/src/progress-schema");
const path_1 = require("path");
const rxjs_1 = require("rxjs");
const operators_1 = require("rxjs/operators");
const file_watcher_1 = require("./utils/file-watcher");
const playwright_1 = require("./utils/playwright");
function playwrightBuilder(options, context) {
    const configPath = (0, path_1.resolve)(context.workspaceRoot, options.playwrightConfig);
    const playwrightService = new playwright_1.PlaywrightService(configPath);
    let server = null;
    // startup
    // maybe we need this directly and not later
    // in this case we need something like a model
    const main$ = (0, rxjs_1.from)(playwrightService.initialize())
        .pipe((0, operators_1.switchMap)(() => {
        const target = (0, architect_1.targetFromTargetString)(options.devServerTarget);
        return context.scheduleTarget(target);
    }), (0, operators_1.switchMap)((builderRun) => {
        server = builderRun;
        return builderRun.result;
    }), (0, operators_1.shareReplay)());
    // watch mode
    if (options.watch) {
        const fileWatcherService = new file_watcher_1.FileWatcherService(options.watchDir);
        const progress$ = main$.pipe((0, operators_1.switchMap)(() => { var _a; return (_a = server === null || server === void 0 ? void 0 : server.progress) !== null && _a !== void 0 ? _a : rxjs_1.EMPTY; }), (0, operators_1.filter)((progress) => progress.state === progress_schema_1.State.Stopped), (0, operators_1.map)(() => null));
        return main$.pipe((0, operators_1.switchMap)(() => (0, rxjs_1.merge)(progress$, fileWatcherService.change())), (0, operators_1.switchMap)((result) => {
            const file = (result === null || result === void 0 ? void 0 : result[0])
                ? (0, path_1.resolve)(context.workspaceRoot, result[0])
                : void 0;
            return playwrightService.run(file);
        }));
    }
    return main$.pipe((0, operators_1.switchMap)(() => playwrightService.run()), (0, operators_1.tap)(() => (server === null || server === void 0 ? void 0 : server.stop(), playwrightService.destroy())), (0, operators_1.take)(1)).toPromise();
}
// create builder
exports.default = (0, architect_1.createBuilder)(playwrightBuilder);
