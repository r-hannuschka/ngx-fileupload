"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FileWatcherService = void 0;
const chokidar_1 = require("chokidar");
const rxjs_1 = require("rxjs");
const operators_1 = require("rxjs/operators");
class FileWatcherService {
    constructor(directories) {
        this.directories = directories;
        this.watch$ = null;
    }
    change() {
        if (!this.watch$) {
            this.watch$ = this.initializeWatcher();
        }
        return this.watch$;
    }
    initializeWatcher() {
        const watcher = (0, chokidar_1.watch)(this.directories);
        const change$ = (0, rxjs_1.fromEventPattern)(this.createHandler(watcher, 'change'));
        const ready$ = (0, rxjs_1.fromEventPattern)(this.createHandler(watcher, 'ready'));
        return ready$.pipe((0, operators_1.switchMap)(() => change$));
    }
    createHandler(watcher, event) {
        return (handler) => {
            watcher.on(event, (path, stats) => handler(path, stats));
        };
    }
}
exports.FileWatcherService = FileWatcherService;
