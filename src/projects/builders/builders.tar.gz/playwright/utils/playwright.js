"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PlaywrightService = void 0;
const child_process_1 = require("child_process");
const rxjs_1 = require("rxjs");
const path_1 = require("path");
class PlaywrightService {
    constructor(configPath) {
        this.configPath = configPath;
        this.process = null;
        this.out$ = new rxjs_1.Subject();
        this.configuration = null;
        this.rootDir = null;
    }
    destroy() {
        this.out$.complete();
        if (this.process) {
            this.process.kill();
        }
    }
    async initialize() {
        var _a;
        this.configuration = await Promise.resolve().then(() => __importStar(require(this.configPath)));
        this.rootDir = (0, path_1.join)((0, path_1.dirname)(this.configPath), (_a = this.configuration.testDir) !== null && _a !== void 0 ? _a : '.');
    }
    run(path) {
        var _a;
        if (this.process) {
            this.process.kill();
        }
        // playwright
        const playwrightCommand = process.platform === 'win32' ? 'npx.cmd' : 'npx';
        const playwrightArgs = ['playwright', 'test', `--config=${this.configPath}`];
        if (path && path.trim() !== '') {
            // for windows systems we get something like this foo\\file.spec.ts which not works
            // together with playwright since he do not understand this one (even on windows)
            // and replace with foo/file.spec.ts
            playwrightArgs.push((0, path_1.relative)((_a = this.rootDir) !== null && _a !== void 0 ? _a : '.', path).replace(/\\/g, '/'));
        }
        this.process = (0, child_process_1.spawn)(playwrightCommand, playwrightArgs, {
            stdio: 'inherit'
        });
        this.process.on('exit', () => {
            this.notify({ success: true, error: '' });
            this.process = null;
        });
        this.process.on('error', (error) => this.notify({ success: false, error: error.message }));
        return this.out$.asObservable();
    }
    notify(result) {
        this.out$.next(result);
    }
}
exports.PlaywrightService = PlaywrightService;
